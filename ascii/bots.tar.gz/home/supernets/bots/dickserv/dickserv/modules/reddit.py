#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# reddit.py

import functions
import httplib
from database import Settings

def read(subreddit):
    api  = httplib.get_json('http://www.reddit.com/r/{0}.json?limit={1}'.format(subreddit, Settings.get('max_results')))
    data = [x['data'] for x in api['data']['children']]
    if data:
        results = {}
        for item in data:
            if not item['stickied']:
                results[item['title']] = {'url':item['url'], 'score':item['score'], 'ups':item['ups'], 'downs':item['downs']}
        return results
    else:
        return False
