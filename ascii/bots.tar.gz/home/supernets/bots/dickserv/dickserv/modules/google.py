#!/usr/bin/env python
# DickServ IRC Service Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# google.py

from googleapiclient.discovery import build

import config
from database import Settings

def search(query):
    service = build('customsearch', 'v1', developerKey=config.google_api_key)
    results = service.cse().list(q=query, cx=config.google_cse_id, num=Settings.get('max_results')).execute()
    return results['items']