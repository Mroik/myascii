#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# cryptocurrency.py

import httplib

def value(name):
    api = httplib.get_json('https://min-api.cryptocompare.com/data/price?fsym={0}&tsyms=USD'.format(name.upper()))
    if 'USD' in api:
        return api['USD']
    else:
        return False