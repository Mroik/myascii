#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# tpb.py

import re

import httplib
from database import Settings

def search(query):
    url      = 'https://thepiratebay.org/search/{0}/0/99/0'.format(query.replace(' ', '+'))
    source   = httplib.get_source(url)
    torrents = re.findall('<a href="(.*?)" class="detLink".*>(.*?)</a>', source)
    seeders  = re.findall('\t\t</td>\n\t\t<td align="right">(.*?)</td>', source)
    leechers = re.findall('<td align="right">(.*?)</td>\n\t</tr>',       source)
    if torrents:
        results = {}
        torrents = torrents[:Settings.get('max_results')]
        for i in range(len(torrents)):
            results[torrents[i][1]] = {'seeders':seeders[1], 'leechers':leechers[i], 'url':torrents[i][0]}
        return results
    else:
       return False
