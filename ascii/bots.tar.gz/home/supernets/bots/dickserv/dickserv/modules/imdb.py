#!/usr/bin/env python
# DickServ IRC Service Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# imdb.py

import re

import httplib

def check(url):
    id = re.findall('imdb.com/title/(.*?)/', url, re.IGNORECASE|re.MULTILINE)
    if id:
        return id[0]
    else:
        return False

def search(query):
    if query.startswith('tt') and len(query) == 9:
        api = httplib.get_json('http://omdbapi.com/?i=' + query)
    else:
        year = query.split()[-1]
        if len(year) == 4 and year.isdigit():
            query = query[:-5].replace(' ', '%20')
            api = httplib.get_json('http://omdbapi.com/?t={0}&y={1}'.format(query, year))
        else:
            query = query.replace(' ', '%20')
            api = httplib.get_json('http://omdbapi.com/?t=' + query)
    if api['Response'] == 'True':
        return api
    else:
        return False

