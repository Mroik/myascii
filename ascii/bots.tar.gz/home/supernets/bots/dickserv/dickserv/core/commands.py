#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# commands.py

import cryptocurrency
import dictionary
import geoip
import google
import imdb
import isup
import netsplit
import reddit
import tpb
import tripsit
import weather
import wolfram
import youtube
