#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# irc.py

import re
import socket
import ssl
import time

import config
import debug
import functions
import httplib

from commands import *
from database import Ignore, Settings, Todo

#socket.setdefaulttimeout(15)

# Formatting Control Characters / Color Codes
bold          = '\x02'
italic        = '\x1D'
underline     = '\x1F'
reverse       = '\x16'
reset         = '\x0f'
white         = '00'
black         = '01'
blue          = '02'
green         = '03'
red           = '04'
brown         = '05'
purple        = '06'
orange        = '07'
yellow        = '08'
light_green   = '09'
cyan          = '10'
light_cyan    = '11'
light_blue    = '12'
pink          = '13'
grey          = '14'
light_grey    = '15'

class IRC(object):
    server       = config.server
    port         = config.port
    use_ipv6     = config.use_ipv6
    use_ssl      = config.use_ssl
    vhost        = config.vhost
    password     = config.password
    channel      = config.channel
    key          = config.key
    nickname     = config.nickname
    username     = config.username
    realname     = config.realname
    nickserv     = config.nickserv
    oper_passwd  = config.oper_passwd
    admin_host   = config.admin_host
    unreal_modes = config.unreal_modes

    def __init__(self):
        self.last_time  = 0
        self.slow       = False
        self.start_time = 0
        self.status     = True
        self.sock       = None

    def color(self, msg, foreground, background=None):
        if foreground == 'random':
            foreground = '{0:0>2}'.format(functions.random_int(2,13))
        if background == 'random':
            background = '{0:0>2}'.format(functions.random_int(2,13))
        if background:
            return '\x03{0},{1}{2}{3}'.format(foreground, background, msg, reset)
        else:
            return '\x03{0}{1}{2}'.format(foreground, msg, reset)

    def connect(self):
        try:
            self.create_socket()
            self.sock.connect((self.server, self.port))
            if self.password:
                self.raw('PASS ' + self.password)
            self.raw('USER {0} 0 * :{1}'.format(self.username, self.realname))
            self.raw('NICK ' + self.nickname)
        except Exception as ex:
            debug.error('Failed to connect to IRC server.', ex)
            self.event_disconnect()
        else:
            self.listen()

    def create_socket(self):
        if self.use_ipv6:
            self.sock = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        else:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if self.vhost:
            self.sock.bind((self.vhost, 0))
        if self.use_ssl:
            self.sock = ssl.wrap_socket(self.sock)

    def error(self, chan, msg, reason=None):
        if reason:
            self.sendmsg(chan, '[{0}] {1} {2}'.format(self.color('ERROR', red), msg, self.color('({0})'.format(str(reason)), grey)))
        else:
            self.sendmsg(chan, '[{0}] {1}'.format(self.color('ERROR', red), msg))

    def event_connect(self):
        self.start_time = time.time()
        if self.unreal_modes:
            self.mode(self.nickname, '+BDN')
        if self.nickserv:
            self.identify(self.username, self.nickserv)
        if self.oper_passwd:
            self.oper(self.username, self.oper_passwd)
        self.join(self.channel, self.key)

    def event_disconnect(self):
        self.sock.close()
        time.sleep(10)
        self.connect()

    def event_kick(self, chan, kicked):
        if chan == self.channel and kicked == self.nickname:
            time.sleep(3)
            self.join(self.channel, self.key)

    def event_message(self, chan, nick, ident, host, msg):
        try:
            if chan == self.channel:
                if not msg.startswith('.'):
                    urls = httplib.parse_urls(msg)
                    if urls:
                        if time.time() - self.last_time > 3:
                            self.last_time = time.time()
                            self.event_url(chan, urls[0])
                    if 'qhat' in msg:
                        self.sendmsg(chan, 'Q:)')
                    elif msg == 'h' and functions.lucky():
                        self.sendmsg(chan, 'h')
                    elif msg == '@help':
                        self.sendmsg(chan, 'https://github.com/acidvegas/dickserv/blob/master/README.md#commands')
                elif host not in Ignore.hosts():
                    cmd  = msg.split()[0][1:]
                    args = msg[len(cmd)+2:]
                    if time.time() - self.last_time < Settings.get('cmd_throttle') and host != self.admin_host:
                        if not self.slow:
                            self.sendmsg(chan, self.color('Slow down nerd!', red))
                            self.slow = True
                    elif self.status or host == self.admin_host:
                        self.slow = False
                        if not args:
                            if cmd == 'date':
                                self.sendmsg(chan, functions.date())
                            elif cmd == 'dickserv':
                                self.sendmsg(chan, bold + 'DickServ IRC Bot - Developed by acidvegas in Python 3 - https://github.com/acidvegas/dickserv')
                            elif cmd == 'talent':
                                if functions.random_int(1,1000) == 420:
                                    self.sendmsg(chan, self.color(' !!! HOLY FUCKING SHIT {0} ACHIEVED TALENT !!! '.format(nick), red, brown))
                                else:
                                    self.sendmsg(chan, self.color('(^)', 'random'))
                            elif cmd == 'todo':
                                todos = Todo.read(ident)
                                if todos:
                                    for item in todos:
                                        count = todos.index(item)+1
                                        self.sendmsg(chan, '{0} {1}'.format(self.color('[{0}]'.format(count), pink), item))
                                else:
                                    self.error(chan, 'No results.')
                            elif cmd == 'uptime':
                                self.sendmsg(chan, functions.uptime(self.start_time))
                        elif cmd == 'coin':
                            api = cryptocurrency.value(args)
                            if api:
                                self.sendmsg(chan, '{0} - ${1}'.format(self.color(args, pink), api))
                            else:
                                self.error(chan, 'No cryptocurrency found!')
                        elif cmd == 'drug':
                            api = tripsit.drug(args)
                            if api:
                                self.sendmsg(chan, '{0} - {1}'.format(self.color(api['name'], yellow), api['desc']))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'define':
                            definition = dictionary.define(args)
                            if definition:
                                self.sendmsg(chan, '{0} - {1}: {2}'.format(self.color('Definition', white, blue), args.lower(), definition))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'g':
                            api = google.search(args)
                            if api:
                                for result in api:
                                    count = api.index(result)+1
                                    self.sendmsg(chan, '{0} {1}'.format(self.color('[{0}]'.format(count), pink), result['title']))
                                    self.sendmsg(chan, ' - ' + self.color(result['link'], grey))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'geoip':
                            if functions.check_ip(args):
                                results = geoip.lookup(args)
                                if results:
                                    self.sendmsg(chan, results)
                                else:
                                    self.error(chan, 'No information found.')
                            else:
                                self.error(chan, 'Invalid IP address.')
                        elif cmd == 'imdb':
                            api = imdb.search(args)
                            if api:
                                self.sendmsg(chan, '{0}Title       :{1} {2}'.format(bold, reset, self.color('{0} {1} {2}'.format(api['Title'], api['Rated'], api['Year']), grey)))
                                self.sendmsg(chan, '{0}Link        :{1} {2}'.format(bold, reset, self.color('http://imdb.com/title/' +  api['imdbID'], grey)))
                                self.sendmsg(chan, '{0}Genre       :{1} {2}'.format(bold, reset, self.color(api['Genre'], grey)))
                                self.sendmsg(chan, '{0}Rating      :{1} {2}'.format(bold, reset, self.color(api['imdbRating'], grey)))
                                prefix = bold + 'Description :' + reset
                                for line in re.findall(r'.{1,60}(?:\s+|$)', api['Plot']):
                                    self.sendmsg(chan, '{0} {1}'.format(prefix, self.color(line, grey)))
                                    prefix = '             '
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'isup':
                            self.sendmsg(chan, '{0} is {1}'.format(args, isup.check(args)))
                        elif cmd == 'netsplit':
                            api = netsplit.search(args)
                            if api:
                                data = list(api.keys())
                                for i in data:
                                    count = str(data.index(i)+1)
                                    self.sendmsg(chan, '{0} {1} {2} / {3}'.format(self.color('[{0}]'.format(str(count)), pink), self.color(i, light_blue), self.color('({0})'.format(api[i]['users']), grey), self.color(api[i]['network'], red)))
                                    self.sendmsg(chan, self.color(' - ' + api[i]['topic'], grey))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'r':
                            api = reddit.read(args)
                            if api:
                                data = list(api.keys())
                                for i in data:
                                    count = str(data.index(i)+1)
                                    self.sendmsg(chan, '{0} {1} {2}{3}{4}{5}{6}'.format(self.color('[{0}]'.format(str(count)), pink), functions.trim(i, 70), self.color('[{0}|'.format(str(api[i]['score'])), white), self.color('+' + str(api[i]['ups']), green), self.color('/', white), self.color('-' + str(api[i]['downs']), red), self.color(']', white)))
                                    self.sendmsg(chan, ' - ' + self.color(api[i]['url'], grey))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'resolve':
                            if functions.check_ip(args):
                                self.sendmsg(chan, socket.gethostbyaddr(args)[0])
                            else:
                                self.sendmsg(chan, socket.gethostbyname(httplib.clean_url(args)))
                        elif cmd == 'todo':
                            split = args.split()
                            if len(split) > 1 and split[0] == 'add':
                                todos = Todo.read(ident)
                                if len(todos) <= Settings.get('max_todo_per') and len(Todo.read()) <= Settings.get('max_todo'):
                                    args = args[4:]
                                    if args not in todos:
                                        Todo.add(ident, args)
                                        self.sendmsg(chan, 'Todo added to database!')
                                    else:
                                        self.error(chan, 'Todo already in database!')
                                else:
                                    self.error(chan, 'Maximum todos reached!')
                            elif len(split) == 2 and split[0] == 'del':
                                num = split[1]
                                if num.isdigit():
                                    num   = int(num)
                                    todos = Todo.read(ident)
                                    if todos:
                                        if num <= len(todos):
                                            for item in todos:
                                                count = todos.index(item)+1
                                                if count == num:
                                                    Todo.delete(ident, item)
                                                    break
                                            self.sendmsg(chan, 'Todo removed from database!')
                                        else:
                                            self.error(chan, 'Invalid number.')
                                    else:
                                        self.error(chan, 'No todos found.')
                                else:
                                    self.error('Invalid number.')
                            else:
                                self.error(chan, 'Invalid arguments.')
                        elif cmd == 'tpb':
                            api  = tpb.search(args)
                            if api:
                                data = list(api.keys())
                                for i in data:
                                    count = str(data.index(i)+1)
                                    self.sendmsg(chan, '{0} {1} {2}{3}{4}{5}{6}'.format(self.color('[{0}]'.format(str(count)), pink), i, self.color('[', white), self.color(api[i]['seeders'], green), self.color('|', white), self.color(api[i]['leechers'], red), self.color(']', white)))
                                    self.sendmsg(chan, ' - ' + self.color('http://thepiratebay.org' + api[i]['url'], grey))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'ud':
                            definition = dictionary.urban(args)
                            if definition:
                                self.sendmsg(chan, '{0}{1} - {2}: {3}'.format(self.color('urban', white, blue), self.color('DICTIONARY', yellow, black), args, definition))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'w':
                            if args.isdigit():
                                api = weather.lookup(args)
                                if api:
                                    self.sendmsg(chan, api)
                                else:
                                    self.error(chan, 'No results found.')
                            else:
                                self.error(chan, 'Invalid arguments.')
                        elif cmd == 'wolfram':
                            results = wolfram.ask(args)
                            if results:
                                self.sendmsg(chan, '{0}{1} - {2}'.format(self.color('Wolfram', red), self.color('Alpha', orange), results))
                            else:
                                self.error(chan, 'No results found.')
                        elif cmd == 'yt':
                            api  = youtube.search(args)
                            if api:
                                data = list(api.keys())
                                for i in api.keys():
                                    count = str(data.index(i)+1)
                                    self.sendmsg(chan, '{0} {1}'.format(self.color('[{0}]'.format(str(count)), pink), functions.trim(i, 70)))
                                    self.sendmsg(chan, ' - ' + self.color(api[i], grey))
                            else:
                                self.error(chan, 'No results found.')
                    self.last_time = time.time()
        except Exception as ex:
            self.error(chan, 'Command threw an exception.', ex)

    def event_nick_in_use(self):
        debug.error_exit('DickServ is already running.')

    def event_private(self, nick, host, msg):
        if host == self.admin_host:
            args = msg.split()
            if len(args) == 1:
                if msg == '.config':
                    settings = Settings.read()
                    self.sendmsg(nick, '[{0}]'.format(self.color('Settings', purple)))
                    for setting in settings:
                        self.sendmsg(nick, '{0} = {1}'.format(self.color(setting[0], yellow), self.color(setting[1], grey)))
                elif msg == '.ignore':
                    ignores = Ignore.read()
                    if ignores:
                        self.sendmsg(nick, '[{0}]'.format(self.color('Ignore List', purple)))
                        for user in ignores:
                            self.sendmsg(nick, '{0} {1}'.format(self.color(user[0], yellow), self.color('({0})'.format(user[1]), grey)))
                        self.sendmsg(nick, '{0} {1}'.format(self.color('Total:', light_blue), self.color(len(ignores), grey)))
                    else:
                        self.error(nick, 'Ignore list is empty!')
                elif msg == '.off':
                    self.status = False
                    self.sendmsg(nick, self.color('OFF', red))
                    self.part(self.channel, 'Bot has been turned off.')
                elif msg == '.on':
                    self.status = True
                    self.sendmsg(nick, self.color('ON', green))
                    self.join(self.channel, self.key)
            elif len(args) == 3:
                if args[0] == '.config':
                    setting, value = args[1], args[2]
                    if functions.CheckString.number(value):
                        value = functions.floatint(value)
                        if value >= 0:
                            if setting in Settings.settings():
                                Settings.update(setting, value)
                                self.sendmsg(nick, 'Change setting for {0} to {1}.'.format(self.color(setting, yellow), self.color(value, grey)))
                            else:
                                self.error(nick, 'Invalid config variable.')
                        else:
                            self.error(nick, 'Value must be greater than or equal to zero.')
                    else:
                        self.error(nick, 'Value must be an integer or float.')
            elif len(args) == 4:
                if args[0] == '.ignore':
                    if args[1] == 'add':
                        nickname, hostname = args[2], args[3]
                        if hostname != self.admin_host:
                            if len(nickname) <= 20 and len(hostname) <= 63:
                                if functions.CheckString.hostname(hostname) and functions.CheckString.nickname(nickname):
                                    if hostname not in Ignore.hosts():
                                        Ignore.add(nickname, hostname)
                                        self.sendmsg(nick, 'User {0} to the ignore list.'.format(self.color('added', green)))
                                    else:
                                        self.error(nick, 'Host is already on the ignore list.')
                                else:
                                    self.error(nick, 'Nick/Host contains illegal characters.')
                            else:
                                self.error(nick, 'Nick/Host is too long.')
                        else:
                            self.error(nick, 'Admin host can not be ignored.')
                    elif args[1] == 'del':
                        nickname, hostname = args[2], args[3]
                        if hostname in Ignore.hosts():
                            Ignore.remove(nickname, hostname)
                            self.sendmsg(nick, 'User {0} from the ignore list.'.format(self.color('removed', red)))
                        else:
                            self.error(nick, 'User does not exist in the ignore list.')

    def event_url(self, chan, url):
        try:
            if 'imdb.com/title/' in url:
                id  = imdb.check(url)
                api = imdb.search(id)
                if api:
                    self.sendmsg(chan, '{0}Title       :{1} {2}'.format(bold, reset, self.color('{0} {1} {2}'.format(api['Title'], api['Rated'], api['Year']), grey)))
                    self.sendmsg(chan, '{0}Link        :{1} {2}'.format(bold, reset, self.color('http://imdb.com/title/' +  api['imdbID'], grey)))
                    self.sendmsg(chan, '{0}Genre       :{1} {2}'.format(bold, reset, self.color(api['Genre'], grey)))
                    self.sendmsg(chan, '{0}Rating      :{1} {2}'.format(bold, reset, self.color(api['imdbRating'], grey)))
                    prefix = bold + 'Description :' + reset
                    for line in re.findall(r'.{1,60}(?:\s+|$)', api['Plot']):
                        self.sendmsg(chan, '{0} {1}'.format(prefix, self.color(line, grey)))
                        prefix = '             '
            elif youtube.check(url):
                title = youtube.title(url)
                self.sendmsg(chan, '{0}{1} {2}{3}'.format(self.color('You', black, white), self.color('Tube', white, red), bold, title))
            else:
                url_type = httplib.get_type(url)
                if url_type == 'text/html':
                    title = httplib.get_title(url)
                    self.sendmsg(chan, '[{0}] {1}'.format(self.color(url_type, pink), title))
                else:
                    file_name = httplib.get_file(url)
                    if file_name:
                        file_size = httplib.get_size(url)
                        self.sendmsg(chan, '[{0}] {1} [{2}]'.format(self.color(url_type, pink), file_name, self.color(file_size, blue)))
        except Exception as ex:
            debug.error('Title Error', ex)

    def handle_events(self, data):
        args = data.split()
        if args[0] == 'PING':
            self.raw('PONG ' + args[1][1:])
        elif args[1] == '001':
            self.event_connect()
        elif args[1] == '433':
            self.event_nick_in_use()
        elif args[1] == 'KICK':
            nick   = args[0].split('!')[0][1:]
            chan   = args[2]
            kicked = args[3]
            self.event_kick(chan, kicked)
        elif args[1] == 'NOTICE':
            if args[3] == ':***':
                if 'You were forced to join' in data:
                    chan = args[9]
                    self.part(chan)
                elif 'You were forced to part' in data:
                    chan = args[9]
                    time.sleep(3)
                    self.join(chan)
        elif args[1] == 'PRIVMSG':
            nick  = args[0].split('!')[0][1:]
            ident = args[0].split('!')[1]
            host  = ident.split('@')[1]
            chan  = args[2]
            msg   = data.split('{0} PRIVMSG {1} :'.format(args[0], chan))[1]
            if nick != self.nickname:
                if chan == self.nickname:
                    self.event_private(nick, host, msg)
                else:
                    self.event_message(chan, nick, ident, host, msg)

    def identify(self, username, password):
        self.sendmsg('nickserv', 'ghost {0} {1}'.format(username, password))
        self.sendmsg('nickserv', 'identify {0} {1}'.format(username, password))

    def join(self, chan, key=None):
        if key:
            self.raw('JOIN {0} {1}'.format(chan, key))
        else:
            self.raw('JOIN ' + chan)
        self.sendmsg(chan, 'Hello, I am the {0}, type {1} for a list of commands.'.format(self.color('DickServ', pink), self.color('@help', white)))

    def listen(self):
        while True:
            try:
                data = self.sock.recv(1024).decode('utf-8')
                if data:
                    for line in (line for line in data.split('\r\n') if line):
                        debug.irc(line)
                        if line.startswith('ERROR :Closing Link:'):
                            raise Exception('Connection has closed.')
                        elif len(line.split()) >= 2:
                            self.handle_events(line)
                else:
                    debug.error('No data recieved from server.')
                    break
            except (UnicodeDecodeError,UnicodeEncodeError):
                pass
            except Exception as ex:
                debug.error('Unexpected error occured.', ex)
                break
        self.event_disconnect()

    def mode(self, target, mode):
        self.raw('MODE {0} {1}'.format(target, mode))

    def oper(self, username, password):
        self.raw('OPER {0} {1}'.format(username, password))

    def part(self, chan, msg=None):
        if msg:
            self.raw('PART {0} {1}'.format(chan, msg))
        else:
            self.raw('PART ' + chan)

    def raw(self, msg):
        self.sock.send(bytes(msg + '\r\n', 'utf-8'))

    def sendmsg(self, target, msg):
        self.raw('PRIVMSG {0} :{1}'.format(target, msg))

DickServ = IRC()
