#!/usr/bin/env python
# DickServ IRC Service Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# todo.py

import inspect
import os
import sqlite3

# Database Directory & File
database_dir  = os.path.join(os.path.dirname(os.path.realpath(inspect.stack()[-1][1])), 'data')
database_file = os.path.join(database_dir, 'todo.db')

# Globals
db  = sqlite3.connect(database_file)
sql = db.cursor()

def check_database():
    tables = sql.execute('SELECT name FROM sqlite_master WHERE type=\'table\'').fetchall()
    if len(tables):
        return True
    else:
        return False

def create_database():
    sql.execute('CREATE TABLE TODO (IDENT TEXT NOT NULL, DATA TEXT NOT NULL);')
    db.commit()

def read(ident):
    return list(item[0] for item in sql.execute('SELECT DATA from TODO WHERE IDENT=\'{0}\' ORDER BY DATA ASC'.format(ident)).fetchall())

def add(ident, data):
    sql.execute('INSERT INTO TODO (IDENT,DATA) VALUES (\'{0}\', \'{1}\')'.format(ident, data))
    db.commit()

def delete(ident, data):
    sql.execute('DELETE from TODO where IDENT=\'{0}\' and DATA=\'{1}\''.format(ident, data))
    db.commit()