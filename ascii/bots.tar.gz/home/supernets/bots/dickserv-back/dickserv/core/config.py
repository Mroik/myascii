#!/usr/bin/env python
# DickServ IRC Bot
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/dickserv
# config.py

# Connection
server   = 'localhost'
port     = 6697
use_ipv6 = False
use_ssl  = True
vhost    = None
password = None
channel  = '#dev'
key      = None

# Identity
nickname = 'DickServ'
username = 'dickserv'
realname = 'DickServ IRC Bot'

# Login
nickserv    = 'sxLnzp1opXENjR7hPvSLs7OXzBkLmr1L'
oper_passwd = None

# API Keys
google_api_key       = 'AIzaSyAi2TjS-_Falsj34mWXWQtON364JssI72Y' # https://console.developers.google.com/
google_cse_id        = '015901052910302504488:c2oahe2nqna'       # https://cse.google.com/
wolfram_api_key      = 'TX7K2G-K6PYA2V9YP'                       # http://products.wolframalpha.com/api/
wunderground_api_key = '8f51aea8b9f70a0d'                        # https://www.wunderground.com/weather/api/
