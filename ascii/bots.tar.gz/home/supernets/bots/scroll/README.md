# scroll
A bot to play ASCII art for the Internet Relay Chat (IRC) protocol.

###### Information
The bot will join the `channel` defined in the settings, and the `#scroll` channel.

ASCII that exceeds `max_lines` can only be played in the `#scroll` channel.

Turning the bot off will part the bot from the channel defined in the config, but all commands will still function in the `#scroll` channel.

###### Note
The `ascii_list.py` file will generate a text file containing a numbered list of every file in the `/data/` directory. You can upload that list to pastebin or a web-server, and then put the link in `/data/list.txt` so you can have a `.ascii list` command that just sends a link instead of overflowing the channel with file names.

###### Commands
| Command | Description |
| --- | --- |
| .ascii random | Play a random ASCII file. |
| .ascii search \<query> | Search through the ASCII files for \<query>. |
| .ascii stop | Stop playing the current ASCII being scrolled / Stop the auto scroll loop. |
| .ascii \<name> | Play the \<name> ASCII file. |

###### Admin Commands
| Command | Description |
| --- | --- |
| .ascii auto | Automatically scroll random ASCII files. |
| .ascii delete \<name> | Delete the \<name> ASCII file. |
| .ascii get \<pastebin> \<name> | Saves contents of \<pastebin> to \<name> in the database. |
| .ascii rename \<old> \<new> | Rename the \<old> ASCII art file to \<new>. |

###### Admin Commands (Private Message)
| Command | Description |
| --- | --- |
| .config | View the config settings. |
| .config \<setting> \<value> | Change \<setting> to \<value>. |
| .ignore | View the ignore list. |
| .ignore add \<nick> \<host> | Add a user to the ignore list. |
| .ignore del \<nick> \<host> | Remove a user from the ignore list. |
| .off | Toggle the usage of the bot commands. |
| .on | Toggle the usage of the bot commands. |