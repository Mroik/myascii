#!/usr/bin/env python
# Scroll (IRC ASCII Bot)
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/scroll
# functions.py

import string
import urllib.request

class CheckString:
    def filename(data):
        chars = string.ascii_letters + string.digits + '-._'
        return all(c in chars for c in data)

    def hostname(data):
        chars = string.ascii_letters + string.digits + '-.'
        return all(c in chars for c in data)

    def nickname(data):
        chars = string.ascii_letters + string.digits + '`^-_[{]}|\\'
        return all(c in chars for c in data)

    def number(data):
        if len(data) <= 4:
            if data.isdigit():
                return True
            elif data[:1].isdigit() and data.replace('.','',1).isdigit():
                return True
            else:
                return False
        else:
            return False

def floatint(data):
    if data.isdigit():
        return int(data)
    else:
        return float(data)

def save_pastebin(url, ascii_file):
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)')
    source  = urllib.request.urlopen(req, timeout=10)
    charset = source.headers.get_content_charset()
    if charset:
        source = source.read().decode(charset)
    else:
        source = source.read().decode()
    with open (ascii_file, 'w') as ascii__file:
        ascii__file.write(source)