#!/usr/bin/env python
# Scroll (IRC ASCII Bot)
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/scroll
# irc.py

import glob
import inspect
import os
import random
import shutil
import socket
import ssl
import threading
import time

import config
import debug
import functions
from database import Ignore, Settings

# Globals
data_dir  = os.path.join(os.path.dirname(os.path.realpath(inspect.stack()[-1][1])), 'data')
ascii_dir = os.path.join(data_dir, 'ascii')

# Formatting Control Characters / Color Codes
bold        = '\x02'
italic      = '\x1D'
underline   = '\x1F'
reverse     = '\x16'
reset       = '\x0f'
white       = '00'
black       = '01'
blue        = '02'
green       = '03'
red         = '04'
brown       = '05'
purple      = '06'
orange      = '07'
yellow      = '08'
light_green = '09'
cyan        = '10'
light_cyan  = '11'
light_blue  = '12'
pink        = '13'
grey        = '14'
light_grey  = '15'

class IRC(object):
    server       = config.server
    port         = config.port
    use_ipv6     = config.use_ipv6
    use_ssl      = config.use_ssl
    vhost        = config.vhost
    password     = config.password
    channel      = config.channel
    key          = config.key
    nickname     = config.nickname
    username     = config.username
    realname     = config.realname
    nickserv     = config.nickserv
    oper_passwd  = config.oper_passwd
    admin_host   = config.admin_host
    unreal_modes = config.unreal_modes

    def __init__(self):
        self.last_time   = 0
        self.playing     = False
        self.auto_scroll = False
        self.slow        = False
        self.status      = True
        self.stopper     = False
        self.sock        = None

    def color(self, msg, foreground, background=None):
        if background:
            return f'\x03{foreground},{background}{msg}{reset}'
        else:
            return f'\x03{foreground}{msg}{reset}'

    def connect(self):
        try:
            self.create_socket()
            self.sock.connect((self.server, self.port))
            if self.password:
                self.raw('PASS ' + self.password)
            self.raw(f'USER {self.username} 0 * :{self.realname}')
            self.raw('NICK '+ self.nickname)
        except socket.error as ex:
            debug.error('Failed to connect to IRC server.', ex)
            self.event_disconnect()
        else:
            self.listen()

    def create_socket(self):
        if self.use_ipv6:
            self.sock = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        else:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if self.vhost:
            self.sock.bind((self.vhost, 0))
        if self.use_ssl:
            self.sock = ssl.wrap_socket(self.sock)

    def error(self, chan, msg, reason=None):
        if reason:
            self.sendmsg(chan, '[{0}] {1} {2}'.format(self.color('ERROR', red), msg, self.color(f'({reason})', grey)))
        else:
            self.sendmsg(chan, '[{0}] {1}'.format(self.color('ERROR', red), msg))

    def event_connect(self):
        if self.unreal_modes:
            self.mode(self.nickname, '+BDd')
        if self.nickserv:
            self.identify(self.username, self.nickserv)
        if self.oper_passwd:
            self.oper(self.username, self.oper_passwd)
        self.join(self.channel, self.key)
        self.join('#scroll')

    def event_disconnect(self):
        self.sock.close()
        time.sleep(10)
        self.connect()

    def event_kick(self, nick, chan, kicked):
        if kicked == self.nickname and chan in (self.channel,'#scroll'):
            time.sleep(3)
            self.join(chan, self.key)

    def event_message(self, nick, host, chan, msg):
        if (chan == self.channel or chan == '#scroll'):
            args = msg.split()
            if args[0] == '.ascii' and host not in Ignore.hosts():
                if time.time() - self.last_time < Settings.get('cmd_throttle') and host != self.admin_host:
                    if not self.slow:
                        self.error(chan, 'Slow down nerd!')
                        self.slow = True
                else:
                    self.slow = False
                    if self.playing or self.auto_scroll:
                        if msg == '.ascii stop':
                            if self.auto_scroll:
                                self.auto_scroll = False
                            if not self.stopper:
                                self.stopper = True
                        else:
                            self.error(chan, 'Please wait for the current ASCII to finish playing!') # TODO: Show this message only one time.
                    elif len(args) == 2:
                        if self.status or chan == '#scroll':
                            option = args[1]
                            if '../' in option:
                                self.error(chan, 'Nice try, nerd!')
                            elif option == 'auto' and host == self.admin_host and not self.auto_scroll:
                                threading.Thread(target=self.auto, args=(chan,)).start()
                            elif option == 'dirs':
                                dirs = glob.glob(os.path.join(ascii_dir, f'**/*/'), recursive=True)
                                if dirs:
                                    for directory in dirs:
                                        count     = dirs.index(directory) + 1
                                        directory = directory.replace(ascii_dir, '', 1)
                                        self.sendmsg(chan, '{0} {1}'.format(self.color('[{0}]'.format(count), pink), directory))
                                else:
                                    self.error(chan, 'No directories found.')
                            else:
                                if option == 'random':
                                    ascii_file = random.choice(glob.glob(os.path.join(ascii_dir, '**/*.txt'), recursive=True))
                                else:
                                    ascii_file = (glob.glob(os.path.join(ascii_dir, f'**/{option}.txt'), recursive=True)[:1] or [None])[0]
                                if ascii_file:
                                    with open(ascii_file, mode='r', encoding='utf8', errors='replace') as ascii__file:
                                        lines = ascii__file.read().splitlines()
                                        if len(lines) > Settings.get('max_lines') and chan != '#scroll':
                                            self.error(chan, 'File is too big.', 'Take it to #scroll')
                                        else:
                                            if args[1] == 'random':
                                                self.sendmsg(chan, ascii_file.replace(ascii_dir, ''))
                                            threading.Thread(target=self.play, args=(chan, lines)).start()
                                else:
                                    self.error(chan, 'Invalid file name.', 'Use ".ascii list" for a list of valid file names.')
                    elif len(args) == 3:
                        if args[1] == 'delete' and host == self.admin_host:
                            filename   = args[2]
                            ascii_file = (glob.glob(os.path.join(ascii_dir, f'**/{filename}.txt'), recursive=True)[:1] or [None])[0]
                            if ascii_file:
                                os.remove(ascii_file)
                                self.sendmsg(chan, 'File deleted.')
                            else:
                                self.error(chan, 'Invalid file name.', 'Use ".ascii list" for a list of valid file names.')
                        elif args[1] == 'play' and host == self.admin_host and not self.auto_scroll:
                            dir         = args[2]
                            ascii_files = glob.glob(os.path.join(ascii_dir, f'{dir}/*.txt'), recursive=True)
                            if ascii_files:
                                threading.Thread(target=self.auto, args=(chan, ascii_files)).start()
                            else:
                                self.error(chan, 'Invalid directory name.', 'Use ".ascii dirs" for a list of valid directory names.')
                        elif args[1] == 'search':
                            query       = args[2]
                            ascii_files = glob.glob(os.path.join(ascii_dir, f'**/*{query}*.txt'), recursive=True)
                            if ascii_files:
                                ascii_files = ascii_files[:Settings.get('max_results')]
                                for file_name in ascii_files:
                                    count     = ascii_files.index(file_name) + 1
                                    file_name = file_name.replace(ascii_dir, '', 1)
                                    self.sendmsg(chan, '{0} {1}'.format(self.color('[{0}]'.format(count), pink), file_name))
                            else:
                                self.error(chan, 'No results found.')
                    elif len(args) == 4 and host == self.admin_host:
                        if args[1] == 'get':
                            pastebin = args[2]
                            if pastebin.startswith('https://pastebin.com/') or pastebin.startswith('http://pastebin.com/'): # TODO: Use regex to parse pastebin links.
                                if '/raw/' not in pastebin:
                                    pastebin = 'http://pastebin.com/raw/' + pastebin.split('pastebin.com/')[1]
                                name = args[3]
                                if functions.CheckString.filename(name):
                                    ascii_file = os.path.join(ascii_dir, name + '.txt')
                                    if not os.path.isfile(ascii_file):
                                        functions.save_pastebin(pastebin, ascii_file)
                                        self.sendmsg(chan, 'ASCII file saved to database.')
                                    else:
                                        self.error(chan, 'File already exists.')
                                else:
                                    self.error(chan, 'File name contains illegal characters.')
                            else:
                                self.error(chan, 'Invalid Pastebin URL.', pastebin)
                        elif args[1] == 'move':
                            file_name = args[2]
                            ascii_file = os.path.join(ascii_dir, file_name + '.txt')
                            if os.path.isfile(ascii_file):
                                dir_name = args[3]
                                new_dir = os.path.join(ascii_dir, dir_name)
                                new_file = os.path.join(new_dir, file_name + '.txt')
                                shutil.move(ascii_file, new_file)
                        elif args[1] == 'rename':
                            file_name = args[2]
                            if functions.CheckString.filename(file_name):
                                ascii_file = os.path.join(ascii_dir, file_name + '.txt')
                                if os.path.isfile(ascii_file):
                                    new_name = args[3]
                                    if functions.CheckString.filename(new_name):
                                        new_file = os.path.join(ascii_dir, new_name + '.txt')
                                        if not os.path.isfile(new_file):
                                            os.rename(ascii_file, new_file)
                                            self.sendmsg(chan, 'File renamed.')
                                        else:
                                            self.error(chan, 'Failed to rename file.', f'{new_file} already exists.')
                                    else:
                                        self.error(chan, 'Invalid characters in file name.')
                                else:
                                    self.error(chan, 'Invalid file name.', 'Use ".ascii list" for a list of valid file names.')
                            else:
                                self.error(chan, 'File name contains illegal characters.')
                self.last_time = time.time()

    def event_private(self, nick, host, msg):
        if host == self.admin_host:
            args = msg.split()
            if len(args) == 1:
                if msg == '.config':
                    settings = Settings.read()
                    self.sendmsg(nick, '[{0}]'.format(self.color('Settings', purple)))
                    for setting in settings:
                        self.sendmsg(nick, '{0} = {1}'.format(self.color(setting[0], yellow), self.color(setting[1], grey)))
                elif msg == '.ignore':
                    ignores = Ignore.read()
                    if ignores:
                        self.sendmsg(nick, '[{0}]'.format(self.color('Ignore List', purple)))
                        for user in ignores:
                            self.sendmsg(nick, '{0} {1}'.format(self.color(user[0], yellow), self.color(f'({user[1]})', grey)))
                        self.sendmsg(nick, '{0} {1}'.format(self.color('Total:', light_blue), self.color(len(ignores), grey)))
                    else:
                        self.error(nick, 'Ignore list is empty!')
                elif msg == '.off':
                    self.auto_scroll = False
                    self.status      = False
                    self.stopper     = True
                    self.sendmsg(nick, self.color('OFF', red))
                    self.part(self.channel, 'Bot has been turned off.')
                elif msg == '.on':
                    self.status  = True
                    self.stopper = False
                    self.sendmsg(nick, self.color('ON', green))
                    self.join(self.channel, self.key)
            elif len(args) == 3:
                if args[0] == '.config':
                    setting, value = args[1], args[2]
                    if functions.CheckString.number(value):
                        value = functions.floatint(value)
                        if value >= 0:
                            if setting in Settings.settings():
                                Settings.update(setting, value)
                                self.sendmsg(nick, 'Change setting for {0} to {1}.'.format(self.color(setting, yellow), self.color(value, grey)))
                            else:
                                self.error(nick, 'Invalid config variable.')
                        else:
                            self.error(nick, 'Value must be greater than or equal to zero.')
                    else:
                        self.error(nick, 'Value must be an integer or float.')
            elif len(args) == 4:
                if args[0] == '.ignore':
                    if args[1] == 'add':
                        nickname, hostname = args[2], args[3]
                        if hostname != self.admin_host:
                            if len(nickname) <= 20 and len(hostname) <= 63:
                                if functions.CheckString.hostname(hostname) and functions.CheckString.nickname(nickname):
                                    if hostname not in Ignore.hosts():
                                        Ignore.add(nickname, hostname)
                                        self.sendmsg(nick, 'User {0} to the ignore list.'.format(self.color('added', green)))
                                    else:
                                        self.error(nick, 'Host is already on the ignore list.')
                                else:
                                    self.error(nick, 'Nick/Host contains illegal characters.')
                            else:
                                self.error(nick, 'Nick/Host is too long.')
                        else:
                            self.error(nick, 'Admin host can not be ignored.')
                    elif args[1] == 'del':
                        nickname, hostname = args[2], args[3]
                        if hostname in Ignore.hosts():
                            Ignore.remove(nickname, hostname)
                            self.sendmsg(nick, 'User {0} from the ignore list.'.format(self.color('removed', red)))
                        else:
                            self.error(nick, 'User does not exist in the ignore list.')

    def event_nick_in_use(self):
        debug.error_exit('Scroll is already running.')

    def handle_events(self, data):
        args = data.split()
        if args[0] == 'PING':
            self.raw('PONG ' + args[1][1:])
        elif args[1] == '001':
            self.event_connect()
        elif args[1] == '433':
            self.event_nick_in_use()
        elif args[1] == 'KICK':
            nick   = args[0].split('!')[0][1:]
            chan   = args[2]
            kicked = args[3]
            self.event_kick(nick, chan, kicked)
        elif args[1] == 'PRIVMSG':
            nick = args[0].split('!')[0][1:]
            host = args[0].split('!')[1].split('@')[1]
            chan = args[2]
            msg  = data.split(f'{args[0]} PRIVMSG {chan} :')[1]
            if chan == self.nickname:
                self.event_private(nick, host, msg)
            else:
                self.event_message(nick, host, chan, msg)

    def identify(self, username, password):
        self.sendmsg('nickserv', f'recover {username} {password}')
        self.sendmsg('nickserv', f'identify {username} {password}')

    def join(self, chan, key=None):
        if key:
            self.raw(f'JOIN {chan} {key}')
        else:
            self.raw('JOIN ' + chan)

    def listen(self):
        while True:
            try:
                data = self.sock.recv(1024).decode('utf-8')
                if data:
                    for line in (line for line in data.split('\r\n') if line):
                        debug.irc(line)
                        if len(line.split()) >= 2:
                            if line.startswith('ERROR :Closing Link:'):
                                raise Exception('Connection has closed.')
                            else:
                                self.handle_events(line)
                else:
                    debug.error('No data recieved from server.')
                    break
            except (UnicodeDecodeError,UnicodeEncodeError):
                pass
            except Exception as ex:
                debug.error('Unexpected error occured.', ex)
                break
        self.event_disconnect()

    def mode(self, target, mode):
        self.raw(f'MODE {target} {mode}')

    def oper(self, nick, password):
        self.raw(f'OPER {nick} {password}')

    def part(self, chan, msg=None):
        if msg:
            self.raw(f'PART {chan} {msg}')
        else:
            self.raw('PART ' + chan)

    def auto(self, chan, files=None):
        self.auto_scroll = True
        throttle         = Settings.get('cmd_throttle')
        if files:
            for ascii_file in files:
                if not self.auto_scroll:
                    break
                try:
                    with open(ascii_file, mode='r', encoding='utf8', errors='replace') as ascii__file:
                        lines = ascii__file.read().splitlines()
                        self.sendmsg(chan, os.path.basename(ascii_file))
                        threading.Thread(target=self.play, args=(chan, lines)).start()
                except Exception as ex:
                    debug.error('Error occured in the auto function!', ex)
                    self.auto_scroll = False
                    break
                else:
                    time.sleep(throttle)
                    while self.playing:
                        time.sleep(1)
        else:
            while True:
                if not self.auto_scroll:
                    break
                try:
                    ascii_file = random.choice(glob.glob(os.path.join(ascii_dir, f'**/*.txt'), recursive=True))
                    with open(ascii_file, mode='r', encoding='utf8', errors='replace') as ascii__file:
                        lines = ascii__file.read().splitlines()
                        self.sendmsg(chan, os.path.basename(ascii_file))
                        threading.Thread(target=self.play, args=(chan, lines)).start()
                except Exception as ex:
                    debug.error('Error occured in the auto function!', ex)
                    self.auto_scroll = False
                    break
                else:
                    time.sleep(throttle)
                    while self.playing:
                        time.sleep(1)

    def play(self, chan, lines):
        self.playing = True
        amp          = Settings.get('amp_factor')
        throttle     = Settings.get('msg_throttle')
        for line in [line for line in lines if line]:
            if self.stopper:
                self.stopper = False
                break
            else:
                try:
                    if len(line) <= 400:
                        for i in range(amp):
                            self.sendmsg(chan, line)
                            time.sleep(throttle)
                    else:
                        self.error(chan, 'ASCII contains lines that are too long!')
                        break
                except Exception as ex:
                    debug.error('Error occured in the play function!', ex)
                    break
        self.playing = False

    def raw(self, msg):
        self.sock.send(bytes(msg + '\r\n', 'utf-8'))

    def sendmsg(self, target, msg):
        self.raw(f'PRIVMSG {target} :{msg}')

Scroll = IRC()