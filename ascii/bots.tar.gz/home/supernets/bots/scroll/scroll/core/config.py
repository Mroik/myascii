#!/usr/bin/env python
# Scroll (IRC ASCII Bot)
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/scroll
# config.py

# Connection
server   = 'localhost'
port     = 6697
use_ipv6 = False
use_ssl  = True
vhost    = None
password = None
channel  = '#superbowl'
key      = None

# Identity
nickname = 'scroll'
username = 'scroll'
realname = 'Scroll IRC ASCII Bot'

# Login
nickserv    = 'nXQZnwcdBP9R61ct2EKQJeQx65ppNlPE'
oper_passwd = None

# Other
admin_host   = 'super.nets'
unreal_modes = True # Enable this if the server you are connecting to is running UnrealIRCd.
