#!/usr/bin/env python
# Phalanx (Localhost Version)
# Developed by acidvegas in Python 3
# https://github.com/acidvegas/phalanx
# phalanx_local.py

import random
import socket
import ssl
import string
import threading
import time

# Connection
server   = 'localhost'
port     = 6667
password = None
use_ipv6 = False
use_ssl  = False

# Admin
oper_username = 'phalanx'
oper_passwd   = 'i4mpoWyQCRGZhL2uuPFBDg0THzUOC4LI'

# Other
clones = 50
target = 'lolew'

def debug(msg):
    print(f'{get_time()} | [~] - {msg}')

def error(msg, reason=None):
    if reason:
        print(f'{get_time()} | [!] - {msg} ({reason})')
    else:
        print(f'{get_time()} | [!] - {msg}')

def get_time():
    return time.strftime('%I:%M:%S')

def random_int(min, max):
    return random.randint(min, max)

def random_str(size):
    return ''.join(random.sample((string.ascii_letters), size))

class clone(threading.Thread):
    def __init__(self):
        self.nickname = None
        self.username = None
        self.realname = None
        self.sock     = None
        threading.Thread.__init__(self)

    def run(self):
        self.connect()

    def connect(self):
        try:
            self.nickname = random_str(random_int(5,6))
            self.username = random_str(random_int(5,6))
            self.realname = random_str(random_int(5,6))
            self.create_socket()
            self.sock.connect((server, port))
            if password:
                self.raw('PASS ' + password)
            self.raw(f'USER {self.username} 0 * :{self.realname}')
            self.nick(self.nickname)
        except socket.error as ex:
            error('Failed to connect to IRC server.', ex)
            self.event_disconnect()
        else:
            self.listen()

    def create_socket(self):
        if use_ipv6:
            self.sock = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        else:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if use_ssl:
            self.sock = ssl.wrap_socket(self.sock)

    def event_connect(self):
        self.oper(oper_username, oper_passwd)

    def event_disconnect(self):
        time.sleep(random_int(3,5))
        self.sock.close()
        self.connect()

    def event_nick_in_use(self):
        self.nickname = random_str(random_int(5,6))
        self.nick(self.nickname)

    def event_oper(self):
        self.raw('SETHOST ' + random_str(random_int(5,10)))

    def event_sethost(self):
        self.sendmsg(target, random_str(random_int(2,5)))
#        self.event_disconnect()

    def handle_events(self, data):
        args = data.split()
        if args[0] == 'PING':
            self.raw('PONG ' + args[1][1:])
        elif args[1] == '001':
            self.event_connect()
        elif args[1] == '381':
            self.event_oper()
        elif args[1] == '396':
            self.event_sethost()
        elif args[1] == '433':
            self.event_nick_in_use()

    def listen(self):
        while True:
            try:
                data = self.sock.recv(1024).decode('utf-8')
                if data:
                    for line in (line for line in data.split('\r\n') if line):
#                        debug(line)
                        if len(line.split()) >= 2:
                            if line.startswith('ERROR :Closing Link:'):
                                raise Exception('Connection has closed.')
                            else:
                                self.handle_events(line)
                else:
                    error('No data recieved from server.')
                    break
            except (UnicodeDecodeError,UnicodeEncodeError):
                pass
            except Exception as ex:
                error('Unexpected error occured.', ex)
                break
        self.event_disconnect()

    def nick(self, nick):
        self.raw('NICK ' + nick)

    def oper(self, nick, password):
        self.raw(f'OPER {nick} {password}')

    def raw(self, msg):
        self.sock.send(bytes(msg + '\r\n', 'utf-8'))

    def sendmsg(self, target, msg):
        self.raw(f'PRIVMSG {target} :{msg}')

# Main
for i in range(clones):
    clone().start()
    time.sleep(0.3)
input('Attacking...')
